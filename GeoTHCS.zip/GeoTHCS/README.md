# GeoTHCS — ứng dụng vẽ hình học THCS

## Tính năng
- Giao diện tiếng Việt, tương thích máy tính, máy chiếu và điện thoại.
- Nhúng GeoGebra Geometry (2D) và GeoGebra 3D Calculator (3D).
- Thư viện hình mẫu: điểm/đoạn thẳng, tam giác, tứ giác, đường tròn, góc/quan hệ và hình khối.
- Nhập lệnh GeoGebra nhiều dòng; phím tắt Ctrl+Enter để chạy.
- Xuất PNG, xuất SVG ở chế độ 2D, lưu tệp bản vẽ `.ggb`.
- Các thao tác hình học thực hiện trong chính bộ dựng hình GeoGebra, có thể kéo thả và xoay mô hình 3D.

## Cách chạy nhanh
1. Giải nén `GeoTHCS.zip`.
2. Mở thư mục `GeoTHCS`.
3. Nhấp đúp `index.html` để mở trong Chrome hoặc Edge.
4. Cho phép kết nối Internet để tải thư viện GeoGebra.

Nếu trình duyệt hạn chế chức năng khi mở file trực tiếp, hãy chạy máy chủ tĩnh cục bộ:

### Cách A — Python
Mở Terminal/Command Prompt trong thư mục có `index.html`, chạy:
```bash
python -m http.server 8000
```
Sau đó mở `http://localhost:8000`.

### Cách B — VS Code
Cài tiện ích Live Server, nhấp phải `index.html` → Open with Live Server.

## Đưa ứng dụng lên mạng
Có thể tải toàn bộ `index.html` lên dịch vụ hosting tĩnh như GitHub Pages, Netlify hoặc Cloudflare Pages. Không cần API key và không có backend riêng trong bản này.

## Lưu ý quan trọng
- GeoTHCS dùng `https://www.geogebra.org/apps/deployggb.js`; vì vậy cần Internet và phụ thuộc vào dịch vụ GeoGebra.
- PNG được xuất từ vùng đồ họa qua API `getPNGBase64`.
- SVG được xuất qua API `exportSVG` ở chế độ hình học 2D. GeoGebra API không hỗ trợ xuất SVG từ vùng 3D; ở chế độ 3D hãy dùng PNG hoặc menu xuất có sẵn của GeoGebra.
- Nút “Lưu tệp GeoGebra” tải về `.ggb`, có thể mở lại trong GeoGebra.
- Các lệnh dựng hình sử dụng cú pháp lệnh GeoGebra tiếng Anh (ví dụ `Polygon(A,B,C)`, `Circle(O,A)`, `Sphere((0,0,0),2)`). Nếu lệnh mẫu nào không được phiên bản GeoGebra hiện tại chấp nhận, hãy sửa lệnh hoặc tạo hình bằng thanh công cụ của GeoGebra.
- Đây là bản web app phía trình duyệt, chưa có tài khoản, cơ sở dữ liệu đám mây hay chức năng chia sẻ bản vẽ giữa giáo viên. Tệp `.ggb` được lưu về thiết bị người dùng.
- Bản mẫu chưa được kiểm thử trực tiếp trên mọi trình duyệt/thiết bị; cần chạy thử trong môi trường của trường trước khi sử dụng chính thức.

## Nguồn kỹ thuật
- GeoGebra Apps Embedding: https://geogebra.github.io/docs/reference/en/GeoGebra_Apps_Embedding/
- GeoGebra Apps API: https://geogebra.github.io/docs/reference/en/GeoGebra_Apps_API/
- GeoGebra 3D Calculator: https://help.geogebra.org/hc/en-us/articles/8493632359069-3D-Calculator
